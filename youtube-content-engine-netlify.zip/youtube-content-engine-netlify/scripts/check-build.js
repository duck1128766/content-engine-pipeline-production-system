import { access, readFile } from 'node:fs/promises';
const required = ['public/index.html','public/styles.css','public/app.js','netlify/functions/engine.mjs','netlify/functions/engine.md','netlify.toml'];
for (const file of required) await access(new URL(`../${file}`, import.meta.url));
const html = await readFile(new URL('../public/index.html', import.meta.url), 'utf8');
if (!html.includes('id="app"')) throw new Error('App mount point missing');
console.log('Build check passed. Netlify static files and function assets are present.');
