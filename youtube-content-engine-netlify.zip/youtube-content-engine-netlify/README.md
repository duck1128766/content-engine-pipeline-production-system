# YouTube Content Engine v5.5 — Netlify edition

A dark, local-first AI workspace based on the supplied `youtube-content-engine-v5-5.md`. It includes a checkpoint dashboard, project switching, local autosave, command shortcuts, a server-side AI function, JSON project export, and a full-workflow system prompt sourced from the uploaded file.

## Features and boundaries

- Preserves the source's 13 numbered states and STATE 6.5 QA checkpoint. States 8 and 9 are conditional in the source workflow and explicitly support the sourced-visual skip.
- The server function loads the original workflow from `netlify/functions/engine.md` and uses it as the AI instruction specification.
- API keys are read only from Netlify environment variables. No key field exists in the browser.
- Project history is saved to browser `localStorage`; it does not sync between devices and may be cleared by browser settings.
- The app does not itself browse the web, inspect uploaded screenshots, generate images, or create Word documents. The model must be truthful about capabilities. Add dedicated integrations if you want those functions executed rather than planned.
- AI responses are probabilistic. Treat the workflow's factual verification and production QA as a guided process, not a guarantee that every claim is verified.

## Deploy to Netlify

1. Create a new GitHub repository and upload the contents of this folder, or drag the folder into a Git provider flow that Netlify supports.
2. In Netlify, choose **Add new site → Import an existing project** and select the repository.
3. Build settings: publish directory `public`; functions directory `netlify/functions`. The included `netlify.toml` already sets these values.
4. In **Site configuration → Environment variables**, add:
   - `OPENAI_API_KEY` = your secret API key
   - `OPENAI_MODEL` = a model enabled for your API account, e.g. `gpt-4.1-mini`
   - Optional `OPENAI_BASE_URL` = `https://api.openai.com/v1/chat/completions` for the standard API, or a compatible Chat Completions endpoint.
   - Optional `ALLOWED_ORIGIN` = your exact deployed origin, e.g. `https://your-site-name.netlify.app`. Leave unset if you use Netlify deploy-preview URLs and understand the trade-off.
5. Trigger a deploy. Open the site's URL and test the first checkpoint.
6. If you add or change environment variables, redeploy the site.

**Billing:** API usage is billed by the AI provider separately from Netlify hosting. Never commit a real API key to Git or put it in `public/app.js`.

## Run locally

Requires Node.js 20+.

```bash
npm install
# Create a local .env file (do not commit it):
# OPENAI_API_KEY=your_key_here
# OPENAI_MODEL=gpt-4.1-mini
npx netlify dev
```

Netlify CLI reads `.env` locally. Use the local URL printed by the CLI. If needed, use `netlify env:import .env` only when you intentionally want to sync values into your Netlify site; do not do that with a shared or untrusted site.

## Build check

```bash
npm run build
```

## Security notes

- The function accepts POST only, checks payload sizes, limits conversation history sent to the model, and never returns the secret key.
- `ALLOWED_ORIGIN` is an optional origin check, not user authentication. For a public app, add authentication and rate limiting before sharing widely; otherwise visitors can consume your API quota.
- The function currently calls a Chat Completions-compatible endpoint. If you use a different provider, update the request format in `netlify/functions/engine.mjs`.
- Browser local storage is not encrypted. Do not store sensitive credentials or private account information in project notes.

## Workflow controls

Use the left navigation to move between states. Moving to a later state manually is available for recovery, but the AI instructions still require validation and explicit checkpoint handling. Use `next`, `fix`, `redo`, `pick best`, `make it viral`, and the source-defined change commands in the chat. A state is marked completed only when the app detects an appropriate completion signal; review the response yourself.

## Project structure

```text
public/
  index.html       Dashboard UI
  styles.css       Dark responsive dashboard
  app.js           Workflow state, local storage, chat UI, exports
netlify/
  functions/
    engine.mjs     Secure server-side AI proxy
    engine.md      Original v5.5 workflow source
netlify.toml       Netlify build, function, redirect, and headers config
package.json       Local Netlify CLI and build-check scripts
scripts/
  check-build.js   Project file validation
```
